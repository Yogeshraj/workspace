<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
  <div class="footer">
  <div class="container">
    <p>WEB TEAM. ECC. 2018<p>
  </div>
</div> 